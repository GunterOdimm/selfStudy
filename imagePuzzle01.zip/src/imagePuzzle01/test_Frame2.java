package imagePuzzle01;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class test_Frame2 extends JFrame implements ActionListener {

	test_Frame ts = new test_Frame();

	long start = System.currentTimeMillis();

	JButton[] btn;
	int count = 0, game[], row = 5, col = 5;
	int clickCount, oldNum, curNum;
	Image original;
	BufferedImage img[];

	public test_Frame2() {
		test_Frame ts = new test_Frame();
		String userImage = ts.getFilePath();
		MediaTracker tracker = new MediaTracker(this);
		// 미디어 트래커를 이용해 이미지를 가지고오자.
		original = Toolkit.getDefaultToolkit().getImage(userImage);
		tracker.addImage(original, 0);
		try {
			tracker.waitForAll();
		} catch (InterruptedException e) {
			;
		}
		int width = original.getWidth(this) / col;
		// 넓이는 col로 나누어 주자
		int height = original.getHeight(this) / row;
		// 높이는 row로 나누어 주자.
		setSize(new Dimension(width * col, height * row));
		// 높이 넓이를 각각 정해주자.

		img = new BufferedImage[row * col];
		// 이미지 품질을 유지
		int cnt = 0;
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				img[cnt] = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
				Graphics g = img[cnt].getGraphics();
				g.drawImage(original, 0, 0, width, height, j * width, i * height, (j + 1) * width, (i + 1) * height,
						this);
				// 원본이미지에서 필요한 부분만 잘라낸 다음 사용하자.
				cnt++;
			}
		}

		// 게임배열
		game = new int[row * col];

		// 버튼을 만들기
		btn = new JButton[row * col];

		for (int i = 0; i < row * col; i++) {
			btn[i] = new JButton();
			btn[i].addActionListener(this);
			add(btn[i]);
		}
		// 숫자 섞고 버튼에 이미지 입히기
		shuffle();
		// 나눴으면 섞어주자.
		setLayout(new GridLayout(row, col));

		setResizable(false);
		setVisible(true);

	}

	// 숫자 섞고 버튼에 이미지 입히기
	private void shuffle() {
		Random rnd = new Random();
		// 섞는 값은 매번 랜덤으로 돌려주자.

		do {
			for (int i = 0; i < row * col; i++)
				game[i] = 0;

			// 배열에 중복값을 제거해야한다.
			for (int i = 0; i < row * col; i++) {
				int temp = 0;
				do {
					temp = rnd.nextInt(row * col);
				} while (game[temp] != 0);
				game[temp] = i;
			}
		} while (endGame());

		for (int i = 0; i < row * col; i++) {
			btn[i].setIcon(new ImageIcon(img[game[i]]));
		}

	}

	public void actionPerformed(ActionEvent e) {

		JButton curBtn = (JButton) e.getSource();

		for (int i = 0; i < btn.length; i++) {
			if (curBtn.getIcon().equals(btn[i].getIcon())) {
				curNum = i;
				break;
			}
		}

		if (clickCount == 0) {
			clickCount++;
			oldNum = curNum;
		} else {
			if (oldNum != curNum) {

				btn[oldNum].setIcon(new ImageIcon(img[game[curNum]]));
				btn[curNum].setIcon(new ImageIcon(img[game[oldNum]]));

				int t = game[oldNum];
				game[oldNum] = game[curNum];
				game[curNum] = t;

				if (endGame()) {
					int[][] scorebord = new int[10][3];
					long end = System.currentTimeMillis();
					long secDiffTime = (end - start) / 1000;
					JOptionPane.showMessageDialog(this, "성공했습니다!" + secDiffTime + "초 만큼걸렸습니다");

					Custom c = new Custom();
					c.setSecDiffTime(secDiffTime);

					/*
					 * int reStart = JOptionPane.showConfirmDialog(this, "재시작할까요?", "종료할까요?",
					 * JOptionPane.YES_NO_OPTION); if (reStart == JOptionPane.YES_OPTION) {
					 * shuffle(); repaint();
					 * 
					 * } else { System.exit(0); }
					 */
				}
			}
			clickCount = 0;

		}
	}

	private boolean endGame() {
		boolean endGame = true;

		for (int i = 0; i < game.length; i++) {
			if (i != game[i]) {
				endGame = false;
			}
		}

		return endGame;

	}

}