package imagePuzzle01;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class firstPage {
	public static void main(String[] args) {
		test_Frame tf = new test_Frame();
	}
}

class test_Frame extends JFrame implements ActionListener {

	static String filePath = "1.jpg";

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	Container contentPane;
	JLabel imageLabel = new JLabel();
	JButton jbt1 = new JButton("쉬움");
	JButton jbt2 = new JButton("보통");
	JButton jbt3 = new JButton("어려움");
	test_Frame0 tf2;
	test_Frame1 tf3;
	test_Frame2 tf4;

	public test_Frame() {
		this.setLayout(new GridLayout(0, 2));
		getContentPane().add(jbt1);
		getContentPane().add(jbt2);
		getContentPane().add(jbt3);

		JMenuBar mb = new JMenuBar();
		JMenu fileMenu = new JMenu("설정");
		JMenuItem openItem = new JMenuItem("그림선택");

		// Open 메뉴아이템에 Action 리스너를 등록한다.
		openItem.addActionListener(new OpenActionListener());
		fileMenu.add(openItem);
		mb.add(fileMenu);

		this.setJMenuBar(mb);
		this.setSize(300, 300);
		this.setVisible(true);

		jbt1.addActionListener(this);
		jbt2.addActionListener(this);
		jbt3.addActionListener(this);
	}

	class OpenActionListener implements ActionListener {
		JFileChooser chooser;

		OpenActionListener() {
			chooser = new JFileChooser(); // 파일 다이얼로그 생성
		}

		public void actionPerformed(ActionEvent e) {
			FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & GIF","jpg", "gif"); // 파일 필터로 사용되는 확장자. *.jpg. *.gif만 나열됨
			chooser.setFileFilter(filter); // 파일 다이얼로그에 파일 필터 설정

			// 파일 다이얼로그 출력
			int ret = chooser.showOpenDialog(null);
			if (ret != JFileChooser.APPROVE_OPTION) { // 사용자가 창을 강제로 닫았거나 취소 버튼을 누른 경우
				JOptionPane.showMessageDialog(null, "파일을 선택하지 않았습니다", "경고", JOptionPane.WARNING_MESSAGE);
				return;
			}

			// 사용자가 파일을 선택하고 "열기" 버튼을 누른 경우
			filePath = chooser.getSelectedFile().getPath(); // 파일 경로명을 알아온다.
			return;
		}
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if (arg0.getSource() == jbt1) {
			tf2 = new test_Frame0();
		}
		if (arg0.getSource() == jbt2) {
			tf3 = new test_Frame1();
		}
		if (arg0.getSource() == jbt3) {
			tf4 = new test_Frame2();
		}

	}

	public static void main(String[] args) {
		new test_Frame0();
	}
}
